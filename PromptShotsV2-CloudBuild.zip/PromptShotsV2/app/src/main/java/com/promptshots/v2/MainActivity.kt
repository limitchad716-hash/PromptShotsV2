package com.promptshots.v2

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var prompts: EditText
    private lateinit var interval: EditText
    private lateinit var mode: RadioGroup
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("promptshots", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 28, 22, 22); setBackgroundColor(0xFFF5F7FB.toInt()) }
        root.addView(TextView(this).apply { text = "PROMPT SHOTS V2"; textSize = 25f; setTextColor(0xFF172033.toInt()); setPadding(0,0,0,8) })
        root.addView(TextView(this).apply { text = "FLOATING AUTOMATION CONTROLLER"; textSize = 11f; setTextColor(0xFF667085.toInt()) })
        root.addView(TextView(this).apply { text = "Content type"; textSize = 16f; setPadding(0,22,0,8) })
        mode = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val image = RadioButton(this).apply { text = "Image"; id = 1 }
        val video = RadioButton(this).apply { text = "Video"; id = 2 }
        mode.addView(image); mode.addView(video); mode.check(if (prefs.getString("mode", "Image") == "Video") 2 else 1)
        root.addView(mode)
        root.addView(TextView(this).apply { text = "Prompts (separate each prompt with a blank line)"; textSize = 16f; setPadding(0,18,0,8) })
        prompts = EditText(this).apply { hint = "Prompt 1...\n\nPrompt 2...\n\nPrompt 3..."; gravity = Gravity.TOP; minLines = 7; setPadding(14,14,14,14); setBackgroundColor(0xFFFFFFFF.toInt()); setText(prefs.getString("prompts", "")) }
        root.addView(prompts, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(TextView(this).apply { text = "Time interval (seconds)"; textSize = 16f; setPadding(0,16,0,6) })
        interval = EditText(this).apply { setText(prefs.getInt("interval", 5).toString()); inputType = 2; hint = "5" }
        root.addView(interval)
        val permission = Button(this).apply { text = "1. Allow floating window"; setOnClickListener { if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } }
        root.addView(permission)
        val accessibility = Button(this).apply { text = "2. Enable Prompt Shots accessibility"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        root.addView(accessibility)
        val launch = Button(this).apply { text = "SAVE & SHOW FLOATING WINDOW"; setOnClickListener {
            val seconds = interval.text.toString().toIntOrNull()?.coerceIn(1, 3600) ?: 5
            prefs.edit().putString("prompts", prompts.text.toString()).putString("mode", if (mode.checkedRadioButtonId == 2) "Video" else "Image").putInt("interval", seconds).apply()
            if (Settings.canDrawOverlays(this@MainActivity)) startService(Intent(this@MainActivity, FloatingControllerService::class.java))
            else Toast.makeText(this@MainActivity, "Please allow floating window first.", Toast.LENGTH_LONG).show()
        } }
        root.addView(launch)
        setContentView(root)
    }
}

package com.promptshots.v2

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import android.graphics.Color
import android.view.View
import android.view.MotionEvent
import android.view.WindowManager.LayoutParams

class FloatingControllerService : Service() {
    private lateinit var wm: WindowManager
    private var panel: android.view.View? = null
    private val handler = Handler(Looper.getMainLooper())
    private var prompts = listOf<String>()
    private var index = 0
    private var running = false
    private var intervalMs = 5000L
    private var status: TextView? = null

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { showPanel(); return START_STICKY }

    private fun showPanel() {
        if (panel != null || !Settings.canDrawOverlays(this)) return
        val prefs = getSharedPreferences("promptshots", MODE_PRIVATE)
        prompts = prefs.getString("prompts", "")!!.split(Regex("\\n\\s*\\n")).map { it.trim() }.filter { it.isNotBlank() }
        intervalMs = (prefs.getInt("interval", 5).coerceIn(1, 3600) * 1000L)
        val type = LayoutParams.TYPE_APPLICATION_OVERLAY
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,14,16,14); setBackgroundColor(Color.rgb(24,31,46)) }
        val header = TextView(this).apply { text = "PROMPT SHOTS  •  ${prefs.getString("mode", "Image")}"; textSize = 14f; setTextColor(Color.WHITE) }
        status = TextView(this).apply { text = "Ready • ${prompts.size} prompts"; textSize = 12f; setTextColor(Color.LTGRAY); setPadding(0,8,0,8) }
        val run = Button(this).apply { text = "▶ RUN"; setOnClickListener { startRun() } }
        val stop = Button(this).apply { text = "■ STOP"; setOnClickListener { stopRun() } }
        val close = Button(this).apply { text = "Hide"; setOnClickListener { stopRun(); stopSelf() } }
        box.addView(header); box.addView(status); box.addView(run); box.addView(stop); box.addView(close)
        val lp = LayoutParams(300, LayoutParams.WRAP_CONTENT, type, LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 150 }
        panel = box
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm.addView(box, lp)
    }

    private fun startRun() {
        if (running) return
        if (prompts.isEmpty()) { status?.text = "No prompts saved. Open app and add prompts."; return }
        if (PromptAccessibilityService.instance == null) { status?.text = "Enable Accessibility in Android Settings first."; return }
        running = true; index = 0
        status?.text = "Running • 0/${prompts.size}"
        pasteNext()
    }
    private fun pasteNext() {
        if (!running) return
        if (index >= prompts.size) { running = false; status?.text = "Finished • ${prompts.size}/${prompts.size}"; return }
        val ok = PromptAccessibilityService.instance?.pasteCurrentPrompt(prompts[index]) ?: false
        index++
        status?.text = if (ok) "Pasted • $index/${prompts.size}" else "Paste failed • $index/${prompts.size}. Focus Flow prompt field."
        if (index < prompts.size && running) handler.postDelayed({ pasteNext() }, intervalMs)
        else { running = false; if (ok) status?.text = "Finished • $index/${prompts.size}" }
    }
    private fun stopRun() { running = false; handler.removeCallbacksAndMessages(null); status?.text = "Stopped • $index/${prompts.size}" }
    override fun onDestroy() { stopRun(); panel?.let { wm.removeView(it) }; panel = null; super.onDestroy() }
}

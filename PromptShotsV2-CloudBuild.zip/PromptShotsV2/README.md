# Prompt Shots V2 (Android Studio source project)

This is a starter implementation based on the requested workflow. It is a source project, **not a compiled APK**.

## Features
- Image / Video mode selector (mode label for the user's Flow workflow)
- Multi-prompt text area; separate prompts with a blank line
- Adjustable interval in seconds
- Floating overlay with RUN / STOP / Hide
- Accessibility-based paste into the currently focused text field

## Build
1. Open this folder in Android Studio (recent version with Android Gradle Plugin 8.9.1 support).
2. Allow Gradle sync and install Android SDK 35 if prompted.
3. Build > Build APK(s).

## First-run setup
1. Install the APK built by Android Studio.
2. Open Prompt Shots V2 and choose Image or Video.
3. Enter prompts separated by a blank line and set interval.
4. Grant "Display over other apps" and enable Prompt Shots accessibility service in Android Settings.
5. Open Google Flow in the foreground and tap its prompt input field.
6. Open the floating controller and tap RUN. STOP cancels the queue.

## Important limitations
- Android accessibility/clipboard behavior varies by device and by the Google Flow UI. The service can paste only into the currently focused editable field; it cannot guarantee Flow accepted a prompt or finished generating an image/video.
- The interval is a fixed delay between paste attempts, not a detection of generation completion. Keep Google Flow foregrounded and verify each prompt before relying on a batch.
- The Image/Video choice is stored and displayed as a workflow mode; it does not change Google Flow's own generation controls.
- Review the Accessibility permission carefully. It is used only to paste the prompts you queued after you explicitly press RUN.
